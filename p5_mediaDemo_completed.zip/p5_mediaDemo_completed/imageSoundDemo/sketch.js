/// Image and Sound Demo
/// Note: If you want to include sound,
/// you need to include p5 sound library
/// delete comments from index.html

var cat;
var meow;

function preload() {
  cat = loadImage("cat.png"); //// Load in a kitty image
  meow = loadSound("meow.mp3"); // Load meow mp3
}
function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(255,0,0);
  imageMode(CENTER); // center image

  /// cat follows mouse
  image(cat, mouseX, mouseY,
    cat.width/3, cat.height/3); //reduce size of cat image

  if (mouseIsPressed) {
    if (meow.isPlaying() == false) {
      meow.play();
    }
  }

}

/// Image and Sound Demo
/// Note: If you want to include sound,
/// you need to include p5 sound library
/// delete comments from index.html

function setup() {
  // put setup code here
}

function draw() {
  // put drawing code here
}
